#include <iostream>
#include <vector>
using namespace std;


int main()
{
	vector<char> container;

	container.push_back('A');
	container.push_back('B');
	container.push_back('C');
	container.push_back('D');

	for (int i = 0; i <4; i++)
		cout << "container[" << i << "] == " << container[i] << endl;

	std::vector<char>::iterator p = container.begin();
	cout << "The third entry is " << container[2] << endl; //just for vectors and arrays
	cout << "The third entry is " << p[2] << endl; // works for any random access iterator
	cout << "The third entry is " << *(p+2) << endl; // works for any randome access iterator

	cout << "Back to container[0]." << endl;
	p = container.begin();
	cout << "which has value " << *p << endl;

	cout << "Two steps forward and one step back." << endl; //Is this a Paula Abdul citation?
	p++;
	cout << *p << endl;
	p++;
	cout << *p << endl;
	p--;
	cout << *p << endl;
    
	return 0;
}