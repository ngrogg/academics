#include <iostream>
#include <vector>
using namespace std;
/* This version uses just namespace std, but you need to apply the scope resolution 
operator when declaring the iterator. This is probably a cleaner version. */

int main()
{
	vector<int> container;

	for (int i = 1; i <=4; i++)
		container.push_back(i);
	
	cout << "Here is what is in the container: " << endl;
	std::vector<int>::iterator p;
	for (p=container.begin(); p!= container.end(); p++)
	{
		cout << *p << " ";
	}
	cout << endl;

	cout << "Setting entries to zero." << endl;

	for (p=container.begin(); p!= container.end(); p++)
	{
		*p=0;
	}

	cout << "The container now contains: " << endl;
	for (p=container.begin(); p!= container.end(); p++)
	{
		cout << *p << " ";
	}
	cout << endl;

	return 0;
}





