#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main()
{
	vector<char> line;

	cout << "Enter a line of text: " << endl;
	char next;
	cin.get(next);
	while( next != '\n')
	{
		line.push_back(next);
		cin.get(next);
	}

	// Locate the first occurence of an e in the vector line
	std::vector<char>::const_iterator where;
	where = find(line.begin(), line.end(), 'e'); 

	std::vector<char>::const_iterator p;
	cout << "You entered the following before you entered your first e: " << endl;

	for (p = line.begin(); p != where; p++)
		cout << *p;
	cout << endl;

	cout << "You entered the following after that: " << endl;
	for (p = where; p != line.end(); p++)
		cout << *p;
	cout << endl;

	cout << "End of Demonstration." << endl;

	return 0;
}