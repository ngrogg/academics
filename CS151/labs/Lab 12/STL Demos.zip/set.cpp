#include<iostream>
#include<set>
using namespace std;

int main()
{
	set<char> s;

	s.insert('A');
	s.insert('D');
	s.insert('D');
	s.insert('C');
	s.insert('C');
	s.insert('B');

	cout << "The set contains: " << endl;
	std::set<char>::const_iterator p;
	for(p=s.begin(); p!= s.end(); p++)
		cout << *p << " ";
	cout << endl;

	cout << "Removing C." << endl;
	s.erase('C');
	
	cout << "The set now contains: " << endl;
	for(p=s.begin(); p!= s.end(); p++)
		cout << *p << " ";
	cout << endl;

	return 0;
}
