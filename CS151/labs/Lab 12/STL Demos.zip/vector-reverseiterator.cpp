// Program 18-3 from Savitch
// Ye Olde Reverse Iterator
#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
using namespace std;

int main()
{
	srand(time(0));
	vector<char> container;

	container.push_back('A');
	container.push_back('B');
	container.push_back('F');
	container.push_back('!');
	container.push_back('C');

	cout << "Forward: " << endl;

	std::vector<char>::iterator p;
	for (p = container.begin(); p!=container.end(); p++)
		cout << *p << " ";
	cout << endl;

	cout << "Reverse: " << endl;
	std::vector<char>::reverse_iterator rp;
	for (rp=container.rbegin(); rp != container.rend(); rp++)
		cout << *rp << " ";
	cout << endl;

	sort(container.begin(), container.end());
	cout << "In order the values are: ";
	for (p = container.begin(); p != container.end(); p++)
		cout << *p << " ";
	cout << endl;

	random_shuffle(container.begin(), container.end());
	cout << "Shuffled: ";
	for (p = container.begin(); p != container.end(); p++)
		cout << *p << " ";
	cout << endl;


	return 0;
}