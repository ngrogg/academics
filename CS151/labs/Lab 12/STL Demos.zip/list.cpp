#include<iostream>
#include<list>
using namespace std;

int main()
{
	list<int> list_object;

	for (int i = 1; i <=3 ; i++)
		list_object.push_back(i);

	cout << "List contains: " << endl;
	std::list<int>::iterator iter;
	for (iter = list_object.begin(); iter != list_object.end(); iter++)
		cout << *iter << " ";
	cout << endl;

	cout << "Setting all entries to 0: " << endl;
	for (iter = list_object.begin(); iter != list_object.end(); iter++)
		*iter = 0;

	cout << "List now contains: " << endl;
	for (iter = list_object.begin(); iter != list_object.end(); iter++)
		cout << *iter << " ";
	cout << endl;

	return 0;
}